# Workbench by Sun — W2 assets v1

Direction: modular blue/teal W with script card and warm solar join.
Tagline: Scripts. Tools. Flow.

## Contents
- branding/assets/readme-banner.png: native 2172 × 724 banner.
- branding/assets/symbol.png: transparent 1024 × 1024 canonical symbol, centered with consistent padding.
- branding/assets/icons/: PNG icons at 16, 24, 32, 48, 64, 96, 128, 180, 192, 256, 512, 1024 px. All are direct Lanczos resizes of symbol.png.
- branding/assets/social-preview.png: 1280 × 640; social-card.png: 1200 × 630. Banner fitted without distortion onto navy.
- branding/assets/refs/: original exploration and full-resolution transparent extraction source.
- PREVIEW.png: banner, light/dark symbol review, small-size previews.

## Usage
Keep PNG transparency. Do not stretch, recolor or redraw the symbol. Preserve square icon canvases and padding. Use the same master for future sizes. Very small icons retain the full artwork; fine script strokes and texture naturally become less visible.

The banner was expanded from W2 using image generation; the symbol was isolated with image generation using that banner as reference, then centered and resized programmatically. Generative extraction may introduce slight pixel-level differences; icon sizes are deterministic copies of the same symbol master.

This package is an artwork handoff, not a repository migration or product-name availability clearance.
